import json
import atexit

_database = {}

def getKey(table, key):
    return _database.get(table, {}).get(key)

def hasKey(table, key):
    return key in _database.get(table, {})

def makeTable(table, value=None):
    _database[table] = {**(value if value else {}),**_database.get(table, {})}

def getTable(table):
    return _database.get(table)

def writeKey(table, key, value):
    _database.get(table, {})[key] = value

def reset():
    global _database
    with open('db.json', 'w+') as file:
        file.write('{}')
    _database = {}

@atexit.register
def dump_db():
    with open('db.json', 'w+') as file:
        json.dump(_database, file)

try:
    with open('db.json', 'r') as file:
        _database = json.load(file)
except:
    reset()
