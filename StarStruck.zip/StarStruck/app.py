from flask import Flask, make_response, jsonify, request, render_template
import database

app = Flask(__name__)

database.makeTable('links')
database.makeTable('stars')

@app.route('/api/links', methods=['GET'])
def get_links():
    return jsonify(database.getTable('links'))

@app.route('/api/links/<user_id>', methods=['GET'])
def get_links_for_id(user_id):
    links = database.getKey('links', user_id)
    if links is None:
        database.writeKey('links', user_id, [])
        links = []
    return jsonify([l for l in links if l is not None])

@app.route('/api/links/<user_id>/<int:link_num>', methods=['GET', 'DELETE'])
def specific_link(user_id, link_num):
    links = database.getKey('links', user_id)
    if links is None:
        return make_response(jsonify({'error':'user has no links'}), 404)
    if link_num < 0 or link_num >= len(links) or links[link_num] is None:
        return make_response(jsonify({'error':'user has no link with that id'}), 404)
    if request.method == 'GET':
        return jsonify(links[link_num])
    links[link_num] = None
    database.writeKey('links', user_id, links)
    return jsonify({'success': 'deleted successfully'})

@app.route('/api/links/<user_id>', methods=['POST'])
def new_link(user_id):
    data = request.get_json(force=True)
    if not ('p0' in data and 'p1' in data):
        return make_response(jsonify({'error': 'missing args'}), 404)
    links = database.getKey('links', user_id)
    links.append([data['p0'], data['p1']])
    database.writeKey('links', user_id, links)
    return jsonify({'link_id': len(links) - 1})

star_id = 0
@app.route('/api/stars', methods=['POST'])
def add_star():
    global star_id
    data = request.get_json(force=True)
    if not ('p0' in data and 'p1' in data and 'p2' in data):
        return make_response(jsonify({'error': 'missing args'}), 404)
    database.writeKey('stars', star_id, [
        data['p0'],
        data['p1'],
        data['p2']
    ])
    star_id += 1
    return make_response(jsonify({'success':'star added'}))

@app.route('/api/stars', methods=['GET'])
def get_stars():
    return database.getTable('stars')

@app.route('/api/kill', methods=['GET'])
def kill():
    import os, signal
    os.kill(os.getpid(), signal.SIGINT)
    return ''

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', debug=False)
    except RuntimeError:
        print('Shutting Down')
