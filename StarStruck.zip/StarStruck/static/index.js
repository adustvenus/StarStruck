const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera( 75, window.innerWidth / window.innerHeight, 0.1, 1000 );
const renderer = new THREE.WebGLRenderer();
renderer.setSize( window.innerWidth, window.innerHeight );
document.body.appendChild( renderer.domElement );

var geometry = new THREE.SphereGeometry(100, 25, 25);
var material = new THREE.MeshBasicMaterial({
  color: 0xFFFF00,
  wireframe: true
});

const sphere = new THREE.Mesh(geometry, material);
const sky_box = new THREE.Object3D();
sky_box.add(sphere)
scene.add(sky_box);
scene.background("stars.jpg");
camera.position.z = 1;
const controls = new THREE.OrbitControls( camera, renderer.domElement );
controls.enableZoom = true;
controls.enablePan = false;
const rayCaster = new THREE.Raycaster();
const mousePosition = new THREE.Vector2();
const canvas = renderer.domElement;
const canvasPostition = $(canvas).position();
renderer.domElement.onclick = (evt) => {
  mousePosition.x = ((evt.clientX - canvasPostition.left) / canvas.width) * 2 - 1;
  mousePosition.y = -((evt.clientY - canvasPostition.top) / canvas.height) * 2 + 1;
  rayCaster.setFromCamera(mousePosition, camera);
  var intersects = rayCaster.intersectObjects(scene.children);
  console.log(intersects)
};
function animate() {
  controls.update();
   requestAnimationFrame( animate );
   renderer.render( scene, camera );
}
animate();
